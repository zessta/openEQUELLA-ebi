function writeFlash( swf, x, y)
{
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="');
document.write(x);
document.write('" height="');
document.write(y);
document.write('" id="Flash" align="middle"><param name="allowScriptAccess" value="sameDomain"><param name="movie" value="');
document.write(swf);
document.write('""><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><PARAM NAME="wmode" VALUE="transparent"><embed src="');
document.write(swf);
document.write('"quality="high" bgcolor="#ffffff" width="');
document.write(x);
document.write('" height="');
document.write(y);
document.write('"wmode="transparent" name="Flash" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></object>');

}