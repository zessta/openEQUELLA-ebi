var myimages = new Array();

function preloadimages(){
	for(var i=0;i<preloadimages.arguments.length;i++){
		myimages[i] = new Image();
		myimages[i].src = preloadimages.arguments[i];
	}
}

preloadimages("images/back.png","images/next.png","images/close.png","images/instruction.png","images/botstrip.jpg","images/banner.jpg","images/header.png","images/audio-bg.png","images/album_loader.gif","images/buffer1.png","images/buffer2.png","images/play-1.png","images/play-2.png","images/pause-1.png","images/pause-2.png","images/progress_sprite.jpg","images/myanswerwidebg.png","images/right.png","images/wrong.png","images/flowplayer-3.2.7.swf","images/animal-1-over.png","images/animal-2-over.png","images/animal-3-over.png","images/animal-4-over.png","images/IMG10168.jpg","audio/AVA10721.mp3","audio/AVA10724.mp3","audio/AVA10721.ogg","audio/AVA10724.ogg","images/back-deselect.png","images/back-down.png","images/back-hover.png","images/back-n.png","images/next-deselect.png","images/next-down.png","images/next-hover.png","images/next-n.png");