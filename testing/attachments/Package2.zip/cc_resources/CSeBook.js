function checkPop(){
window.open("/ec/Courses/13775/CRS-DVUO-2148869/JavaScript/HTML/Popup_Test.html", "Poptest","width=1,height=1,top=350,left=400,screenX=400,screenY=350,location=no, menubar=no, status=no, toolbar=no, scrollbars=no,resizable=no");
}



function GenerateEBookLink( contentID, title )
{
return "<p><font size=2 color=navy>" + title + "</font></p>"
}

function GenerateEBookLinkWithIcon( contentID, title )
{
return "<p><font size=2 color=navy>" + title + "</font></p>"
}


function GenerateEBookLinkWithIcon( contentID, title, filesize )
{
 if (GenerateEBookLinkWithIcon.arguments.length > 2 )
 {
return "<p><font size=2 color=navy>" + title + "</font></p>"

 }
 else 
 {
return "<p><font size=2 color=navy>" + title + "</font></p>"
}
}


function GenerateEBookLinkDual( contentID ){
	return "<font size=2> <A onclick=\"javascript:checkPop();window.open('/ec/cust/Follett/DownloadEBook.learn?KtsID=" 
    + contentID
    + "','eBook','toolbar=no,menubar=no,status=no,width=480,height=300')\" href='#'>PDF</a>&nbsp;|&nbsp;<A onclick=\"javascript:checkPop();window.open('/ec/cust/Follett/ViewEBook.learn?KtsID="
	+ contentID
	+	"&type=view','eBook','toolbar=no,menubar=no,status=no,width=480,height=300')\" href=\"#\">HTML</a></font>"
	
}

function GenerateScribeLink( contentID )
{
	// This script sets OSName variable as follows:
// "Windows"    for all versions of Windows
// "MacOS"      for all versions of Macintosh OS
// "Linux"      for all versions of Linux
// "UNIX"       for all other UNIX flavors 
// "Unknown OS" indicates failure to detect the OS

var OSName="Unknown OS";
var ScribeInstall="this";
if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";

if (OSName == "Windows") 
{
	ScribeInstall="http://downloads.cafescribe.com/MyScribeSetup.exe";
}
else if (OSName == "MacOS") 
{
	ScribeInstall="http://downloads.cafescribe.com/MyScribeSetup.dmg";
}
else
{
	ScribeInstall = "http://cafescribe.com";
}

return "<div style='font-family: Arial,Verdana, Helvetica, sans-serif; padding: 10px;"
+ "color: #000080; font-style: normal; font-weight: 500; outline-color: #FFFFFF;'>"
+ "<P style='font-family: Arial,Verdana, Helvetica, sans-serif; color: #000080; font-style: normal; font-weight: 500;'><font size=2>Access your textbook in one of two ways:"
+ "<ul><li><font size=2><strong>MyScribe:</strong> You should install the MyScribe application to your computer and open the program to access your book."
+ "&nbsp;&nbsp;If you have not installed MyScribe onto your computer already, please download the <A href=" + ScribeInstall + " target=_blank>MyScribe installation file.</a>"
+ "&nbsp;&nbsp;  Step-by-step instructions are located in the <A href=\"/ec/Courses/13775/CRS-DVUO-2148869/SSO/hub2/sso.html?node=809\" target=_blank>MyScribeFAQ.</a>"
+ "<br /><br /><strong>Important</strong> � the link above is <strong>NOT</strong> a link to your book; "
+ "it is a link to download the MyScribe application.  Once you have " 
+ "installed and activated this program on your computer, current and future books will automatically download to your computer.<br />"
+ "<br /><span style='font-family:Arial; color:Navy;'><font size=2>Login to your MyScribe program using:<br />"
+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Username: <strong>your DSI</strong>&nbsp;<em>using a lower case d as the first character, as in - d43215678</em><br />"
+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password: <strong>devry</strong></font></span>"
+ "</font></li><br><br />"
+ "<li><font size=2><strong>HTML:</strong> If you would prefer to use the <strong>HTML</strong> version of your text, you can "
	+ "<A onclick=\"javascript:checkPop();window.open('/ec/cust/Follett/ViewEBook.learn?KtsID="
	+ contentID
	+	"&type=view','eBook','toolbar=no,menubar=no,status=no,width=480,height=300')\" href=\"#\">open it here.</a></font></li></ul></p>"
+ "<P style='font-family: Arial,Verdana, Helvetica, sans-serif; color: #000080; font-style: normal; font-weight: 500;'><font size=2>There is no need to buy a printed version of the textbook.  "
+ "For an additional cost, you can purchase a printed copy of the textbook; feel free to visit the online bookstore, "
+"<A href=\"http://www.devry.efollett.com\" target=_blank><STRONG>Follett Express</STRONG></A>, or your campus bookstore.</font></p>"
+ "<\/div>"	
}


//http://devryu.net/ec/Courses/13775/CRS-DVUO-2148869/MyScribe/msfaq.pdf\