// JavaScript Document
var config = {
	titulo:"AQUISIÇÃO DE UM NEGÓCIO EXISTENTE",
	descricao:"Compreenda as vantagens e desvantagens de comprar um negócio existente, em vez de começar um negócio totalmente novo, de forma tal que você seja capaz de apontar os riscos e oportunidades nos negócios existentes e os critérios para  sua avaliação.",
	telas:9
};