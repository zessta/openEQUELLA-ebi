// JavaScript Document
var config = {
	titulo:"Planejamento Estratégico",
	descricao:"Compreenda a importância do planejamento para entender melhor a necessidade de sua atuação, como profissional de marketing, em parceria com outras áreas da empresa, para alcançar resultados mais promissores",
	telas:37
};