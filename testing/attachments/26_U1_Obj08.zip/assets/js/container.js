// JavaScript Document

document.onselectstart = function() { return false; }
document.onmousedown = function() { return false; }

var container = {
	telaAtual:"01",
	init:function(){
		$('#tx-titulo').html(config.titulo);
		$('#tx-descricao').html(config.descricao);
		$('#tx-tela-de').html(container.trataNumero(config.telas));
		
		//$(document).bind('touchmove', false);
		
		container.carregaHTML('telas/creditos.html', '#creditos-tela');
		container.carregaHTML('telas/referencias.html', '#referencias-tela');
		
		container.carregaMenu();
		
		$('#bt-menu').bind("click", function(evt){
			evt.preventDefault();
			$('#bt-fechar a').trigger("click");
			$('#menu-tela').toggleClass("aberto");
		});
		
		$('#bt-referencias').bind("click", function(evt){
			evt.preventDefault();
			$('#bt-fechar a').trigger("click");
			$('#referencias-tela').toggleClass("aberto");
		});
		
		$('#bt-creditos').bind("click", function(evt){
			evt.preventDefault();
			$('#bt-fechar a').trigger("click");
			$('#creditos-tela').toggleClass("aberto");
		});
		
		
		$('#bt-fechar a').bind("click", function(evt){
			evt.preventDefault();
			$('#menu-tela').removeClass('aberto');
			$('#referencias-tela').removeClass('aberto');
			$('#creditos-tela').removeClass('aberto');
		});
		
		if(config.telas <= 1){
			$("#container .menu .botoes").css("display","none");
			$("#container .menu").css({"background-color":"transparent","width":260});
		}
		container.navigation.carregaTela(container.telaAtual);
		container.navigation.setas();
	},
	trataNumero:function(valor){
		return (parseFloat(valor) < 10 ? ("0"+parseFloat(valor)) : valor);		
//		return (parseFloat(valor) < 10 ? ("0"+parseFloat(valor)) : valor);		
	},
	carregaHTML:function(caminho, pai){
		$.ajax({
			url: caminho,
			success: function(data){
				$(pai + ' #cont-tela').html(data);
			},
			error: function(){
				if(pai == "#creditos-tela"){
					$("#bt-creditos").css("display","none");
					$("#bt-referencias").parent().css("width","100%");
				}else if(pai == "#referencias-tela"){
					$("#bt-referencias").parent().css("display","none");
					$("#bt-creditos").parent().css("width","100%");
				}
				$("#container .menu").css({"background-color":"transparent"});
			}
		})
	},
	carregaMenu:function(){
		$('#menu-tela').append('<ul></ul>');
		for(i=1; i<=84;i++){
			$('#menu-tela ul').append('<li><a href="#" data-tela='+i+'>'+i+'</a></li>');
			if(i>config.telas){
				$('#menu-tela ul li').last().css("opacity","0.1").find('a').removeAttr('href');
			}
		}	
	},
	navigation:{
		carregaTela:function(tela){
			if(tela == 0){
				tela = 1;
			}
			container.telaAtual = tela;

			$("#conteudo").html("");
			$("#loader").html("");
			container.navigation.mostraMensagem("load");
			//return false;
			$('#tx-tela-num').html(container.trataNumero(container.telaAtual));
			$('#bt-proxima').addClass("off");
			$('.barra').width((parseFloat(container.telaAtual)/config.telas)*100+'%')
			
			$.ajax({
				url: "telas/t"+container.trataNumero(tela)+".swf.html",
	
				success: function(data){
					$("#conteudo").html(container.navigation.adjustCode(data));
					container.navigation.animaLoaded();
					
					container.navigation.hasLoaded = true;
				},
				error:function (xhr, ajaxOptions, thrownError){
					container.navigation.handleFileError();
				}
			});
			
			if(parseFloat(container.telaAtual) <= 1){
				$('#bt-anterior').addClass("off");
			}else{
				$('#bt-anterior').removeClass("off");	
			}
			
			if(parseFloat(container.telaAtual) >= config.telas){
				$('#bt-proxima').addClass("off");
			}else{
				//$('#bt-proxima').removeClass("off");
			}
		},
		handleFileError:function() {
			$("#conteudo").html("");
			this.mostraMensagem("erro");
		},
		
		adjustCode:function(data){
			var dataToFind;
			var dataToUse = "";
			
			/*if(data.indexOf("https://www.gstatic.com/swiffy/v5.2") != -1){
				dataToFind = "https://www.gstatic.com/swiffy/v5.2/runtime.js";
				//dataToUse = "../assets/js/runtime5.2.js";
			}else if(data.indexOf("https://www.gstatic.com/swiffy/v5.3") != -1){
				dataToFind = "https://www.gstatic.com/swiffy/v5.3/runtime.js";
				//dataToUse = "../assets/js/runtime5.3.js";
			}else if(data.indexOf("https://www.gstatic.com/swiffy/v5.4") != -1){
				dataToFind = "https://www.gstatic.com/swiffy/v5.4/runtime.js";
				//dataToUse = "../assets/js/runtime5.4.js";
			}else if(data.indexOf("https://www.gstatic.com/swiffy/v7.0") != -1){
				dataToFind = "https://www.gstatic.com/swiffy/v7.0/runtime.js";
				//dataToUse = "../assets/js/runtime7.js";
				//dataToUse = "";
			}else if(data.indexOf("https://www.gstatic.com/swiffy/v7.1") != -1){
				dataToFind = "https://www.gstatic.com/swiffy/v7.1/runtime.js";
			}
			
			
			var rtData;
			rtData = data.split(dataToFind).join(dataToUse);*/
			
			
			var a;
			var regex = new RegExp('<script src=\"https://www.gstatic.com/([^<]+)\"></script\>', 'g');
			var teste = data;
			   
			var match;
			while ((match = regex.exec(teste)))
			{
				a = '<script src="https://www.gstatic.com/'+match[1]+'"></script\>';
				teste = (teste.split(a).join(''));
			}
			return teste;
		},
		
		reloadPage:function(event){
			container.navigation.carregaTela(container.telaAtual);	
		},
		
		mostraMensagem:function(tipo){
			$("#loader").show();
			switch(tipo){
				case "erro":
				var msg = "<div id='boxErro'><p><img src='../assets/images/erro.png' /><br /><br /><br /><a href='#'><img src='../assets/images/tentar.png' /></a></p></div>"
				$("#loader").html(msg);
				break;
				
				case "load":
				//var msg = "<div id='boxLoad'><img src='../assets/images/carregando.gif' /></div>"
				var msg = '  <div class="bouncywrap"><div class="dotcon dc1"><div class="dot"></div></div><div class="dotcon dc2"><div class="dot"></div></div><div class="dotcon dc3"><div class="dot"></div></div></div>';
				$("#loader").html(msg);
				break;
			}
		},

		animaLoaded:function(){
			$("#loader").html("");
			$("#loader").hide();
			//ctx.clearRect(0, 0, canvas.width, canvas.height);
		},
		
		setas:function(){
			$("#bt-anterior").click(function(event){
				event.preventDefault();
				var tela = String(parseFloat(container.telaAtual,10)-1);
				if(tela.length < 2){
					tela = "0"+tela;
				}
				if(parseFloat(tela) > 0){
					container.telaAtual = parseFloat(tela);
					//container.navigation.carregaTela("t"+tela+".swf");
					container.navigation.carregaTela(container.telaAtual);
				}
			});
			
			$("#bt-proxima").click(function(event){
				event.preventDefault();
				var tela = String(parseFloat(container.telaAtual,10)+1);
				if(tela.length < 2){
					tela = "0"+tela;
				}
					
				if(parseFloat(tela) <= config.telas && !$(this).hasClass("off")){
					container.telaAtual = parseFloat(tela);
					container.navigation.carregaTela(container.telaAtual);
				}
			});	
			
			$('#menu-tela ul li a').bind("click",function(evt){
				evt.preventDefault();
				
				$('#menu-tela').toggleClass("aberto");
				
				var tela = String(parseFloat($(this).data('tela'),10));
				
				if(tela.length < 2){
					tela = "0"+tela;
				}
				
				container.telaAtual = tela;
				container.navigation.carregaTela(tela);
				
			});
		},
		fim_da_tela:function(){	
			this.hasLoaded = true;
			
			this.watching = false;
			if(parseFloat(container.telaAtual) == config.telas){
				this.fim_do_curso();
			}else{
				$('#bt-proxima').removeClass("off");
				scorm.data.set("cmi.core.lesson_location",container.telaAtual);	
				//console.log('fim tela');
			}
		},
		
		fim_do_curso:function(){
			scorm.data.set("cmi.core.lesson_status","completed");
		}
		
	}
};

//previne duplo clique zoom
(function($) {
var count = 0;
$.fn.nodoubletapzoom = function() {
	
    $(this).bind('touchstart', function preventZoom(e){
        var t2 = e.timeStamp;
        var t1 = $(this).data('lastTouch') || t2;
        var dt = t2 - t1;
        var fingers = e.originalEvent.touches.length;
        $(this).data('lastTouch', t2);
        if (!dt || dt > 500 || fingers > 1){
            return; // not double-tap
        }
        e.preventDefault(); // double tap - prevent the zoom
        // also synthesize click events we just swallowed up
        $(e.target).trigger('click');
    });
};
})(jQuery);

var scorm;

$(document).ready(function(){
	$("body").nodoubletapzoom();
	
	scorm = pipwerks.SCORM;
	scorm.version = "1.2";
	scorm.connection.initialize();
	
	var telaGravada = scorm.data.get("cmi.core.lesson_location");
	if(telaGravada > 0){
		container.telaAtual = telaGravada;
	}
	
	console.log("Tela Gravada: " + telaGravada);
	
  
   container.init();
   $('body').scrollTop(1);
});

if (!window.console) window.console = {};
if (!window.console.log) window.console.log = function () { };
//Verifica se conexão com LMS ainda está ativa
window.onunload = window.onbeforeunload = function()
{
	if(scorm.connection.isActive)
	{	
		pipwerks.UTILS.trace("Finalizando conexão no Unload");
		scorm.save();
		scorm.quit();
	}
}