var img = new Class({
	Implements: [Options, Events], 
	
	Extends: gadget,
	
	options: {
			src: ''
	},
	
	jQuery: 'img',
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
    this.selector = selector;
    this.setOptions(options);
		$(selector).attr("src", this.options.src);
	},
	
	onDrag: function(event){
		this.parent(event);
		//console.log(event.mode+" "+event.direction);
	},
	
	onSwipe: function(event){
		this.parent(event);
		//console.log(event.mode+" "+event.direction);
	},

	onTap: function(event){
		this.parent(event);
		//console.log("tapping");
	},

	onPinch: function(event){
		this.parent(event);
		//console.log("Pinching rotation "+event.rotation+" scale: "+event.scale);
	},
	
	onFinalPinch: function(event){
		this.parent(event);
		//console.log("Final pinching rotation "+event.rotation+" scale: "+event.scale);
	}
});


