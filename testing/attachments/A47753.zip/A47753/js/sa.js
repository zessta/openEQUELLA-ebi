/**
 *Short answer does not require any input from the json string, so its initial options
 *are empty. 
*/
var sa = new Class({
	Implements: [Options, Events], 
	
	Extends: gadget,
	
	options: {
			src: ''
	},
	
	jQuery: 'sa',
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
    this.selector = selector;
		this.jqObj = $(selector);
		this.value=""; //the value of the textarea input data
		var width = $(selector)[0].offsetWidth-25;
		var height = $(selector)[0].offsetHeight-40;
		$(selector).append("<img src='css/gadget/shortanswer/borderTitle.png' style='position:absolute; left:40px; top:2px; z-index:3;' />");
		$(selector).append("<img src='css/gadget/shortanswer/border.png' style='position:absolute; width:100%; height:100%; left:-2px; top:-4px; z-index:1;' />");
		$(selector).append("<textarea class='sa_text' style='position:absolute; top:10px; left:1px; font:19px Arial; color:#5e5e5e; z-index:2; width:"+width+"px; height:"+height+"px; resize:none; border:0; padding:10px; value=\"\"'></textarea>");
    
		this.restoreSCORMData(); //read from last session's suspend data, populate the gadget. 
    this.syncSCORMData();
		return;
	},
	
	/*
	 This is a gadget specific API. In this case, it regularly check the value of the short answer.
	 It will save the updated value to the SCORM data. 
	*/
	syncSCORMData: function(){
		this.storeSCORMData();
		var me = this;
	  setTimeout(function(){me.syncSCORMData();}, 1000);
	},
	
	/*
	 This is a standard API in each gadget, it will be called when the gadget is initialized,
	 it will look into the SCO level suspend data and retrieve the gadget level data
	*/
	restoreSCORMData: function(){
		var pageId = $(".page").attr("id");
		var gadgetId = this.jqObj.attr("data-id");		
		var gadgetData = scormproxy.getGadgetData(pageId, gadgetId);
		//console.log("Short answer suspend data "+gadgetData);
		if(gadgetData) this.jqObj.find("textarea.sa_text").attr("value", gadgetData);
	},
	
	/*
	 Communicate with the scormproxy to store the current gadget's data into the SCO level suspend data strcture.
	 The data is marked by two layers' ID: the page ID and the gadget id by its attribute of data-id
	*/
	storeSCORMData: function(){
		var newValue = this.jqObj.find("textarea.sa_text").attr("value");
		if(this.value!=newValue){
			this.value=newValue;
			//console.log("Get new input: "+this.value);
			var pageId = $(".page").attr("id");
			var gadgetId = this.jqObj.attr("data-id");
			if(scormproxy) scormproxy.setGadgetData(pageId, gadgetId, this.value);
		}
	}
});


