var buttonizer = new Class({

	Implements: [Options, Events],
	
	options: {	
				states:{
						 over:true,
						 out:true,
						 down:true,
						 up:true
				},	
				over : function over(i, image){
					var buttonStr = image.split('.');
					i.attr('src', buttonStr[0]+'_over.'+buttonStr[1]);
				},
				out : function out(i, image){
					i.attr('src', image);
				},
				up : function up(i, image){
					i.attr('src', image);
				},
				down : function down(i, image){
					var buttonStr = image.split('.');
					i.attr('src', buttonStr[0]+'_down.'+buttonStr[1]);
				},
				enable: true,
				preload : [new Image(), new Image(), new Image()]
  	},
	
	jQuery: 'buttonizer',
	
	initialize: function(selector, options){
   		this.jObject = jQuery(selector);
   		this.setOptions(options);
   		
   		var s = this.jObject.attr('src');
      var reg = new RegExp("\/([a-zA-Z0-9_]+)\.([a-zA-Z]{3})$", "g");
      var btnImg = reg.exec(s);
   		s=s.replace(btnImg[0], "/"); 
      this.options.preload[0].src = s+btnImg[1]+'_over.'+btnImg[2];
      this.options.preload[1].src = s+btnImg[1]+'_down.'+btnImg[2];
      this.options.preload[2].src = s+btnImg[1]+'_up.'+btnImg[2];
   		
   		this.buttonEvt(s+btnImg[1], btnImg[2]);

    },
    
    buttonEvt : function(start, end){
    	var me = this; 
    	var obj = this.jObject;
    	
    	obj.bind('mouseover.button mouseout.button mousedown.button mouseup.button touchstart.button touchend.button',function(e){
    		if(me.options.enable == true){
    			if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
    				if(e.type == 'mouseover'){
    					if( me.options.states.over == true ){
    						me.options.over($(this), start+'.'+end);
    					}
    				}else if(e.type == 'mouseout'){
    					if( me.options.states.out == true ){
    						me.options.out($(this), start+'.'+end);
    					}
    				}else if(e.type == 'mousedown'){
    					if( me.options.states.down == true ){
    						me.options.down($(this), start+'.'+end);
    					}	
    				}else if(e.type == 'mouseup'){
    					if( me.options.states.up == true ){
    						me.options.up($(this), start+'.'+end);
    					}
    				}
    			}else{
    				if(e.type == 'touchstart'){
    					if( me.options.states.down == true ){
    						if(e.originalEvent.touches.length == 1){
		  			 			me.options.down($(this), start+'.'+end);		
							}
    					}
    				}else if(e.type == 'touchend'){
    					if( me.options.states.up == true ){
    						me.options.up($(this), start+'.'+end);
    					}
    				}
    			}
    		}
    	});
    },
    
    enable : function(){
    	this.options.enable = true;
    }, 
    
    disable : function(){
    	this.options.enable = false;
    },  
    
    destroy : function(){
    	this.jObject.unbind('.button');
    }   
});