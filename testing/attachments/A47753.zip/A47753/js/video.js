var VideoScreen = new Class({

 	createScreen : function(){
 	
 		this.html5 = false;
   		var v = document.createElement('video');
   		if(v.canPlayType && v.canPlayType('video/mp4').replace(/no/, '')){
       		this.html5 = true;
   		}
  		if(this.html5 == true){
  			this.HTML();
  		}else{
  			this.flash();
  		}	
 		
 	},//end of createScreen()	
 	
 	HTML : function(){
 		var me = this;
 		var obj = this.jObject;	
 			
 		this.jObject.children('video').each(function(){ //loop thru each video       		
      		var videoId = this.id;
      		var poster = $(this).attr('poster');
      		
      		if( me.options.clip.length > 0 ){
      			var str = $(this).attr('clips');
      			me.clips = str.split(',');
      		}
      		
      		$(this).attr('class', 'video');
      		
      		var clone = obj.html();
      		
      		obj.append('<div class="player">'+clone+'</div>');
      		
      		var newDiv = "<div id='videoplay' playid='"+videoId+"' style='cursor:pointer;'><img id='videoposter' style='border: none;visibility:visible;' src='"+poster+"'/><img id='playbtn' src='css/gadget/video/videoplay.png'/></div>";
	    	
	   		obj.children('.player').after(newDiv);
	  	});
	  		obj.children('video').remove();
	  			  	
	  		obj.children('[playid]').click(function(){
	  		 me.play();
	  	});	
	  	
	  	me.setUpControls();
 	},//end of html5()
 	
 	
 	flash : function(){
 		var me = this;
 		var obj = this.jObject;
 		
 		this.jObject.children('video').each(function(){ //loop thru each video 
      		var videoId = this.id;
      		var poster = $(this).attr('poster');
      		
      		if( me.options.clip.length > 0 ){
      			var str = $(this).attr('clips');
      			me.clips = str.split(',');
      		}
      		
	    	$(this).parent().prepend("<div class='player'><a class='video' style='visibility:hidden;' id='"+videoId+"' href='"+this.src+"'></a></div>");
	    	
	    	var newDiv = "<div id='videoplay' playid='"+videoId+"' style='cursor:pointer;'><img id='videoposter' style='border: none;visibility:visible;' src='"+poster+"'/><img id='playbtn' src='css/gadget/video/videoplay.png'/></div>";
	    	
	   		obj.children('.player').after(newDiv);
	   		$(this).remove();
	  	});	
	  	
	  	obj.children('[playid]').click(function(){
	  		 me.play();
	  	});		
		
		me.canProgress = false;
		//opaque transparent wmode: 'window'
	  	me.flowplayer = flowplayer(obj.children('.player').children('.video').attr('id'), {src: 'js/flowplayer-3.2.7.swf',wmode: 'transparent', allowfullscreen: false}, {
    		clip:  {
    			scaling: 'fit',
    			onBegin: function(){
    				if(me.firstPlay == true){
						me.firstPlay=false;
						obj.children('[playid]').remove();
					}	
    			},
    			onStart: function(){
    				me.options.onplay();
    				me.startCount(); //time here 
    				obj.children('[playid]').remove();
    				obj.children('.controls').children('#play').hide();
					obj.children('.controls').children('#pause').show();
					obj.children('.controls').children('#progress').slider('enable');
  					var self = this;
                    me.setTotalTime(self.getClip().fullDuration);
  					me.data[0] = self.getClip().fullDuration;
  					me.flashTime = setInterval(function() {
  						if(me.canProgress == false){
  							if(self.getState() == 3){
     				 			me.setCurrentTime(self.getTime());
     				 		}	
     					}
  					}, 200);
				},
				onResume: function(){
					var self = this;
					me.options.onplay();
					me.startCount(); //time here
					obj.children('.controls').children('#play').hide();
					obj.children('.controls').children('#pause').show();
					me.flashTime = setInterval(function() {
  						if(me.canProgress == false){
     				 		if(self.getState() == 3){
     				 			me.setCurrentTime(self.getTime());
     				 		}
     					}
  					}, 200);
				},
				onPause: function(){
					clearInterval(me.flashTime);
					me.options.onpause();
					me.endCount(); //stop
					obj.children('.controls').children('#pause').hide();
					obj.children('.controls').children('#play').show();
				},
				onFinish : function(){
					clearInterval(me.flashTime);
					me.options.onend();
					me.endCount();//stop
					obj.children('.controls').children('#pause').hide();
					obj.children('.controls').children('#play').show();
				},
				autoPlay: false,
				autoBuffering: false
			},
			plugins: {                        
				controls: null		                                    
			},
			play: { opacity: 0 }
	  	}); //end of FlowPlayer initialization	
	  	
	  	me.setUpControls();
	  		
 	}//end of flash()	
 
});




var Controls = new Class({

	setUpControls : function(){
		var me = this;
		var obj = this.jObject;
		
		
			obj.append('<div class="controls" id="controls"></div>');
			
			if( me.options.play == true ){
				obj.children('.controls').append('<img class="ctr" id="play" src="css/gadget/video/play.png"/>');
				obj.children('.controls').children('#play').buttonizer();
			}	
			
			if( me.options.pause == true ){
				obj.children('.controls').append('<img style="display:none;" class="ctr" id="pause" src="css/gadget/video/pause.png"/>');
				obj.children('.controls').children('#pause').buttonizer();
			}	
			
			if( me.options.mute == true ){
				if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
					obj.children('.controls').append('<img class="ctr" id="mute" src="css/gadget/video/mute.png"/>');
			
					obj.children('.controls').append('<img style="display:none;" class="ctr" id="unmute" src="css/gadget/video/volume.png"/>');
					obj.children('.controls').children('#unmute').buttonizer();
					obj.children('.controls').children('#mute').buttonizer();
				}
			}	
			
			if( me.options.fullscreen == true ){
				obj.children('.controls').append('<img class="ctr" id="enterFull" src="css/gadget/video/enterFullScreen.png"/>');
		
				obj.children('.controls').append('<img style="display:none;" class="ctr" id="exitFull" src="css/gadget/video/exitFullScreen.png"/>');
				obj.children('.controls').children('#enterFull').buttonizer();
				obj.children('.controls').children('#exitFull').buttonizer();
			}	
			
			if( me.options.time == true ){
				obj.children('.controls').append('<div id="currentTime">00:00</div>');
		
				obj.children('.controls').append('<div id="duration">00:00</div>');
			}	
		
			if( me.options.progressbar == true ){
				obj.children('.controls').append('<div id="progress"></div>');
			}	
			
			if( me.options.volumebar == true ){
				if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
					obj.children('.controls').append('<div id="volumeBar"></div>');
				}
			}	
				
			if( me.options.caption == true ){ 
				obj.append('<div id="subtitle"></div>');
				obj.children('.controls').append('<img style="display:none;" class="ctr" id="showcc" src="css/gadget/video/showCC.png"/>');
				obj.children('.controls').append('<img class="ctr" id="hidecc" src="css/gadget/video/hideCC.png"/>');
				obj.children('.controls').children('#showcc').buttonizer();
				obj.children('.controls').children('#hidecc').buttonizer();
				
				me.getCaption(); 
			}
		
		
		obj.children('.controls').children('.ctr').click(function(){
				var id = this.id;
				
				if(id == "play"){
					me.play();
				}else if(id == "pause"){
					me.pause();
				}else if(id == "mute"){
					me.mute();
				}else if(id == "unmute"){
					me.unmute();
				}else if(id == "enterFull"){
					me.enterFullScreen();
				}else if(id == "exitFull"){
					me.exitFullScreen();
				}else if(id == "showcc"){
					me.showcc();
				}else if(id == "hidecc"){
					me.hidecc();
				}
		});
		
		
		var int;
		
		if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
			
			obj.children('.player').children('.video').bind('mousemove.video',function(){
				//hover
				if(me.isFullScreen == true){
					obj.children('.controls').show();
					clearTimeout(int);
					int = setTimeout(function(){
							obj.children('.controls').fadeOut();
					},1000);
				}
			});	
			
			
			obj.children('.controls').hover(function(){
				//hover
				if(me.isFullScreen == true){
					clearTimeout(int);
					obj.children('.controls').show();
				}
			});
	
		}
		
		me.canProgress = false;
		
		obj.children('.controls').children('#progress').slider({
				range: "min",
				min: 0,
				max: 100,
				create:function(event, ui){$(this).children('.ui-slider-handle').removeAttr('href');},
   				slide: function(event, ui) { 
   						me.canProgress = true;
   						
   						var percent = ui.value/100;
   						var total;
   						var time;
   						
   					if(me.html5 == true){	
   						me.data[0] = total = obj.children('.player').children('video')[0].duration;
   						time = total * percent;
   						me.setCurrentTime(time);
   						obj.children('.player').children('video')[0].currentTime = time;
   						me.options.onseek(time);
   					}else{
   						me.data[0] = total = me.flowplayer.getClip().fullDuration;
   						time = total * percent;
   						me.setCurrentTime(time);
   						me.flowplayer.seek(time);
   						me.options.onseek(time);
   					} 
   				},
   				stop: function(event, ui){
   						me.canProgress = false;	
   				}
		});
		if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
			obj.children('.controls').children('#volumeBar').slider({
				range: "min",
				min: 0,
				max: 100,
				create:function(event, ui){$(this).children('.ui-slider-handle').removeAttr('href');},
   				slide: function(event, ui) {	
   					me.setVolume(ui.value);
   				}
			});
		}
		
		this.isMute = false;
		if(this.html5 == true){	
			me.setVolume(50);
			me.htmlevents();
		}else{
			//slight Timeout needed for flash
			setTimeout(function(){me.setVolume(50);}, 100);
		}	
		
		obj.children('.controls').children('#progress').slider('disable');
		
	},
	
	htmlevents : function(){
		var me = this;
		var obj = this.jObject;
		
		obj.children('.player').children('video')[0].addEventListener("play", function(){
			obj.children('[playid]').remove();
			me.hasEnded = false;
			me.options.onplay();
			if(me.firstPlay == true){
				me.firstPlay=false;
				obj.children('.controls').children('#progress').slider('enable');
				obj.children('.controls').children('#play').hide();
				obj.children('.controls').children('#pause').show();
			}			
		}, true);
		
		var firsttoplay = true;
		obj.children('.player').children('video').get(0).addEventListener("playing", function(){
				me.startCount();//time here
				if(firsttoplay == true){
					firsttoplay = false;
					me.setTotalTime(obj.children('.player').children('video')[0].duration);
					me.data[0] = obj.children('.player').children('video')[0].duration;	
				}
		 }, true);
		
		obj.children('.player').children('video').get(0).addEventListener("pause", function(){
				if(me.hasEnded == false){
					me.endCount();//stop
					me.hasEnded = false;
					me.options.onpause();
				}
		 }, true);
		  
		obj.children('.player').children('video').get(0).addEventListener("ended", function(){
				me.hasEnded = true;
				me.endCount();//stop
				me.options.onend();
				obj.children('.player').children('video')[0].pause();
				obj.children('.controls').children('#pause').hide();
				obj.children('.controls').children('#play').show();
		 }, false); 
		
		obj.children('.player').children('video')[0].addEventListener("timeupdate", function(){ 
				if(me.canProgress == false){
					me.setCurrentTime(obj.children('.player').children('video')[0].currentTime);
				}	
		}, true);
		
		if((/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
			obj.children('.player').children('video')[0].addEventListener("webkitendfullscreen", function(){ 
					me.exitFullScreen();
			}, true);
		
		}
	},
			
	play : function(){
		//this.jObject.children('[playid]').remove();
		this.jObject.children('.controls').children('#play').hide();
		this.jObject.children('.controls').children('#pause').show();
		if(this.html5 == true){
  			this.jObject.children('.player').children('video').get(0).play();
  		}else{
  			if(this.flowplayer.getState() != 3){
  				this.flowplayer.play();
  			}	
  		}
 	}, 
	pause : function(){
		this.jObject.children('.controls').children('#pause').hide();
		this.jObject.children('.controls').children('#play').show();
		if(this.html5 == true){
  			this.jObject.children('.player').children('video').get(0).pause();
  		}else{
  			this.flowplayer.pause();
  		}
 	},
 	
 	mute : function(){
 		this.jObject.children('.controls').children('#mute').hide();
		this.jObject.children('.controls').children('#unmute').show();
 		if(this.html5 == true){
  			this.jObject.children('.player').children('video').get(0).volume = 0;
  			this.isMute = true;
  		}else{
  			this.flowplayer.setVolume(0);
  			this.isMute = true;
  		}
 	},
 	
 	unmute : function(){
 		this.jObject.children('.controls').children('#unmute').hide();
		this.jObject.children('.controls').children('#mute').show();
 		if(this.html5 == true){
 			this.isMute = false;
  			this.jObject.children('.player').children('video').get(0).volume = this.volume;
  		}else{
  			this.flowplayer.setVolume(this.volume);
  			this.isMute = false;
  		}
 	},
 	
 	setCurrentTime : function(time){
 			var me = this;
 			var obj = this.jObject;
 			
 			if( me.options.caption == true ){ 
 				me.showSubs();
 			}
 			
 			me.options.ontimeupdate(time);
 			
 			if( me.options.clip.length > 0 ){
 				var t = Math.floor(time);
 				for(var i = 0; i <= me.clips.length-1; i++){
 					if(me.previous != t){
 						if( t == Math.round(me.clips[i])){
 							me.previous = t;
 							me.options.onclip(me, me.clips, i, t, obj.children('.controls').children('#progress'));
 						}
 					}	
 				}
 			}
 			this.gettime = time;
 			var secVar0 = time;                      
			var minVar = Math.floor(secVar0/60);  
			var secVar = secVar0 % 60;
			if(minVar < 10){ minVar = '0'+Math.floor(minVar);}else{minVar = Math.floor(minVar);}
			if(Math.floor(secVar) < 10){ secVar = '0'+Math.floor(secVar); }else{ secVar = Math.floor(secVar); }
 			this.jObject.children('.controls').children('#currentTime').text(minVar+':'+secVar);
 			
 			if(this.html5 == true){
 				this.setProgress(this.getTime(), this.jObject.children('.player').children('video')[0].duration);
 			}else{
 				this.setProgress(this.getTime(), this.flowplayer.getClip().fullDuration);
 			}	
 	},
 	
 	setTotalTime : function(time){
 			if( this.options.clip.length > 0 ){
 				this.setUpClips(time);
 			}
 			var secVar0 = time;                      
			var minVar = Math.floor(secVar0/60);  
			var secVar = secVar0 % 60;
			if(minVar < 10){ minVar = '0'+Math.floor(minVar);}else{minVar = Math.floor(minVar);}
			if(Math.floor(secVar) < 10){ secVar = '0'+Math.floor(secVar); }else{ secVar = Math.floor(secVar); }
			
 			this.jObject.children('.controls').children('#duration').text(minVar+':'+secVar);
 	},
 	
 	setProgress : function(current, total){
 			var percent = (current/total)*100;
 			this.jObject.children('.controls').children('#progress').slider( "option", "value", percent );
 	},
 	
 	setVolume : function(value){
 		if(this.html5 == true){
 			if(this.isMute == false){
 				value = value/100;
  				this.jObject.children('.player').children('video').get(0).volume = value;
  			}
  			this.volume = value;
  			value = value*100; 
  		}else{
  			if(this.isMute == false){
  				this.flowplayer.setVolume(value);
  			}
  			this.volume = value;	
  		}
  		this.setVolumeBar(value);
 	}, 
 	
 	setVolumeBar : function(number){
 		this.jObject.children('.controls').children('#volumeBar').slider( "option", "value", number );
 	}, 
 	
 	enterFullScreen : function(){
 		var obj = this.jObject;
 		this.options.onfullscreen();
 		this.isFullScreen = true;
 		
 		this.jObject.children('.controls').children('#enterFull').hide();
		this.jObject.children('.controls').children('#exitFull').show();
		
		
		if(!(/iphone|ipod|ipad|android/i).test(navigator.userAgent)){
		this.jObject.children('.controls').delay(1200).fadeOut();
 		
 		this.jObject.addClass('FSMODE');
 		
 		var w = $(window).width();
    	var h = $(window).height();
    	
    	var O =  this.jObject.children('.player').offset(); 
    		 
		this.jObject.children('.player').children('.video').css({height: h, width: w, zIndex:1000,left:0,top:0, textDecoration:'none'});
		this.jObject.children('.player').css({height: h, width: w, top:-O.top, left:-O.left, zIndex: 1000,border:'none'});
		
		$(window).bind('scroll',function() {
   			 obj.children('.player').css('top', $(this).scrollTop()-O.top + "px");
   			 obj.children('.player').css('left', $(this).scrollLeft()-O.left + "px");
		});
		}else{
			this.jObject.children('.player').children('video')[0].webkitEnterFullscreen();
		}
 	}, 
 	
 	exitFullScreen : function(){
 		this.options.onfullscreenexit();
 		this.isFullScreen = false;

 		$(window).unbind('scroll');
 		
 		this.jObject.children('.controls').children('#exitFull').hide();
		this.jObject.children('.controls').children('#enterFull').show();

 			this.jObject.removeClass('FSMODE');
 			
 			this.jObject.children('.player').children('.video').attr('style', '');
			if(this.html5 == false){
				this.jObject.children('.player').children('.video').css('visibility', 'hidden');
			}
			this.jObject.children('.player').attr('style', '');	

 	}, 
 	
 	showcc : function(){
 		this.jObject.children('#subtitle').show();
 		this.jObject.children('.controls').children('#showcc').hide();
		this.jObject.children('.controls').children('#hidecc').show();
 	},
 	
 	hidecc : function(){
 		this.jObject.children('#subtitle').hide();
 		this.jObject.children('.controls').children('#hidecc').hide();
		this.jObject.children('.controls').children('#showcc').show();
 	},
 	
 	getTime : function(){
 			return this.gettime;
 	},
 	
 	seek : function(time){
 			this.options.onseek(time);
 			this.setCurrentTime(time);
 			if(this.html5 == true){	
   				this.jObject.children('.player').children('video')[0].currentTime = time;
   			}else{
   				this.flowplayer.seek(time);
   			}
 	},
 	
 	setUpClips : function(time){
    	var me = this;
		var obj = this.jObject;
		time = Math.floor(time);
		
		
			for(var i = 0; i <= me.clips.length-1; i++){
    			var percent = ( me.clips[i] / time ) * 100;
    			obj.children('.controls').children('#progress').append('<img id="clip'+i+'" class="clip" style="display:none;position:absolute;z-index:2;bottom:0;left:'+percent+'%" src="css/gadget/video/dot.png"/>');
    		}	
    		
    		obj.children('.controls').children('#progress').children('.clip').fadeIn(500);
    }, 
 
 	startCount : function(){
 			var t = new Date();
 			this.startcount = Math.floor(t.getTime() / 1000);
 	},
 	
 	endCount : function(){
 			var t = new Date();
 			var stopcount = Math.floor(t.getTime() / 1000);
 			
 			var time = stopcount - this.startcount;
 			
 			this.data[1] = this.data[1] + time;
 	},
 	
 	getData : function(data){
 			if( data == 'duration' ){
 				return this.data[0];
 			}else if( data == 'timeWatched'  ){
 				return this.data[1];
 			}
 	}		
});




var Captions = new Class({
	
	getCaption : function(){
	    var me = this;
		var obj = this.jObject;
		srtUrl = obj.attr('caption');
		
    	if(srtUrl){
      		$.ajax({
				type:'GET',
				url:srtUrl,
				success:function(data){	
						me.playSubtitles(data);
				}
			});
    	}
	}, 
	
	toSeconds : function(t){
    		var s = 0.0
    		if(t) {
     		var p = t.split(':');
      		for(i=0;i<p.length;i++)
        		s = s * 60 + parseFloat(p[i].replace(',', '.'))
    		}
    		
    		var secVar0 = s;                      
			var minVar = Math.floor(secVar0/60);  
			var secVar = secVar0 % 60;
			if(minVar < 10){ minVar = '0'+Math.floor(minVar);}else{minVar = Math.floor(minVar);}
			if(Math.floor(secVar) < 10){ secVar = '0'+Math.floor(secVar); }else{ secVar = Math.floor(secVar); }
			var string = minVar+':'+secVar;
			return string;
	},
	
	playSubtitles : function(data){
		var me = this;
		var obj = this.jObject;
		
   		var srt = ""+data;
   		srt = srt.replace(/\r\n|\r|\n/g,'<BR>'); 
   	 
    	me.subtitles = {};
    	me.time = {};
    
    	var srt_ = srt.split('<BR><BR>');    	
 		me.l = srt_.length-1;
 
    	for(var s = 0; s <= srt_.length-1; s++){ 
        	st = srt_[s].split('<BR>');
        	if(st.length >=2) {
          		n = st[0];
          		i = st[1].split(' --> ')[0];
          		o = st[1].split(' --> ')[1];
          		t = st[2];
          		if(st.length > 2) {
            		for(j=3; j<st.length;j++)
              		t += '\n'+st[j];
          		}
          		me.time[n] = me.toSeconds(i);
          		me.subtitles[n] = {n: n, o: me.toSeconds(o), t: t};
        	}
    	}
	},	
	
	showSubs : function(){
    	var me = this;
		var obj = this.jObject;
		
    	for(var s = 0; s <= me.l+1; s++){ 
    			if( obj.children('.controls').children('#currentTime').text() >= me.time[s] &&  obj.children('.controls').children('#currentTime').text() <= me.subtitles[s].o){
    				 	obj.children('#subtitle').html(me.subtitles[s].t);	
    			}
    	}	
    }
});

var video = new Class({

	Implements: [Options, Events, VideoScreen, Controls, Captions],
	
	options: {
				play:true,
				pause:true,
				time:true,
				fullscreen:false,
				mute:true,
				progressbar:true,
				volumebar:true,
				caption: false,
				
    			type: "video",
    			skeleton: "model/video.html",
    			src: "auth/asset/video2.mp4",
    			srt: "auth/asset/caption.srt",
    			poster: "auth/asset/p1.jpg",
    			clip: [],
				
				
				
				onplay: function onplay(){}, 
				
				onpause: function onpause(){},
				
				onend: function onend(){},
				
				onmute: function onmute(){}, 
				
				onunmute: function onunmute(){},
				
				onfullscreen: function onfullscreen(){}, 
				
				onfullscreenexit: function onfullscreenexit(){},
				
				ontimeupdate: function ontimeupdate(e){},
				
				onseek: function onseek(e){}, 
				
				onclip: function onclip(me, array, posInArray, time, slider){me.pause();}	
  	},
	
	jQuery: 'video',
	
	initialize: function(selector, options){
   		this.jObject = $(selector);
   		this.setOptions(options);
  		
   		this.firstPlay = true;
   		this.gettime = '0';
   		this.interval;
   		this.previous = 0;
   		this.data = new Array();
   		this.data[0] = 0;
   		this.data[1] = 0;
		this.timewatched = 0; //total time watched in one session

		this.init();
    }, 
    
    init : function(){
    	var me = this;
    	var obj = this.jObject;
    	
    	obj.append('<video id="video"></video>');
    	
    	this.jObject.attr('caption', me.options.srt);
		  this.jObject.children().attr('src', me.options.src).attr('poster',me.options.poster);
		
		if( me.options.clip.length > 0){
				var string = '';
				for(var i = 0; i <= me.options.clip.length-1; i++){
					if(i == me.options.clip.length-1 ){
						string += me.options.clip[i];
					}else{
						string += me.options.clip[i]+',';
					}
				}
				this.jObject.children().attr('clips',string);
		}
															    	
    	this.createScreen();
    }
});


