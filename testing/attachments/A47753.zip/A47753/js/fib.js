var fib = new Class({
	Implements: [Options, Events], 
	
	options: {
		background: 'auth/img/fib.jpg',
		inputs:[
      {"top": "30px", "left": "20px", "width":"215px", "height":"34px"},
      {"top": "80px", "left": "40px", "width":"215px", "height":"34px"}
    ]
	},
	
	jQuery: 'fib', //must be after options
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
    var fibObj = $(selector);
		this.jqObj = $(selector);
		this.options=options;
		this.value=""; //the value of the textarea input data
		
		fibObj.append("<img class='fib_bg' src='"+this.options.background+"' />");
		var inputs = this.options.inputs;
		for(var i=0; i<inputs.length; i++){
			var top=inputs[i].top;
			var left=inputs[i].left;
			var width=inputs[i].width;
			var height=inputs[i].height;
			fibObj.append("<textarea class='fib_zone' style='position:absolute; top:"+top+"; left:"+left+"; width:"+width+"; height:"+height+"; border:0; padding:5px;'></textarea>");
		}

		this.restoreSCORMData(); //read from last session's suspend data, populate the gadget. 
    this.syncSCORMData();		
	},
	
	/*
	 This is a gadget specific API. In this case, it regularly check the value of the short answer.
	 It will save the updated value to the SCORM data. 
	*/
	syncSCORMData: function(){
		this.storeSCORMData();
		var me = this;
	  setTimeout(function(){me.syncSCORMData();}, 1000);
	},
	
	/*
	 This is a standard API in each gadget, it will be called when the gadget is initialized,
	 it will look into the SCO level suspend data and retrieve the gadget level data
	*/
	restoreSCORMData: function(){
		var pageId = $(".page").attr("id");
		var gadgetId = this.jqObj.attr("data-id");		
		var gadgetData = scormproxy.getGadgetData(pageId, gadgetId);
		if(gadgetData){
  		this.value = gadgetData;
			var array = JSON.parse(gadgetData);
			var index=0;
			this.jqObj.find("textarea").each(function(){
				$(this).attr("value", array[index]);
				index++;
			});
		}
	},
	
	/*
	 Communicate with the scormproxy to store the current gadget's data into the SCO level suspend data strcture.
	 The data is marked by two layers' ID: the page ID and the gadget id by its attribute of data-id
	*/
	storeSCORMData: function(){
		var newValue=[]; //construct an empty array
		var index=0;
		
		this.jqObj.find("textarea").each(function(){
			newValue[index] = $(this).attr("value");
		  index++;	
		});
		
		if(this.value!=JSON.stringify(newValue)){
			this.value=JSON.stringify(newValue); //will be an object, not a string
			var pageId = $(".page").attr("id");
			var gadgetId = this.jqObj.attr("data-id");
			if(scormproxy) scormproxy.setGadgetData(pageId, gadgetId, this.value);
			//console.log("Graphic organizer new suspend data "+this.value);
		}
	}	
});


