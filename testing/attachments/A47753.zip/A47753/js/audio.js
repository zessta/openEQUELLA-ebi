/*
 Any DOM node can be enabled to have audio effect by calling
 $("jQSelector").audio({options});
 or
 var a = new Audio("jQSelector", {options});
 
 Note: if the audio target is an image, the image must be styled in CSS with explict width and height in pixels. Otherwise,
 Safari returns the size of 0 which will break the alignment. 
*/
var Audio = new Class({
	Implements: [Options, Events], 
	
	options: {
		src: "auth/asset/AVA101775.mp3",
		showprogress: "true", //whether to show the circle progress, only applied to images
		multistates: "true" //if the audio target is image, it may have multiple states for hover and down
	},
	
	jQuery: 'audio', //must be after options
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
		this.setOptions(options);
		this.audioTarget = $(selector);
		this.audioSrc = this.options.src;
    if($(selector).get(0).nodeName.toLowerCase()=="img"){
			this.isImgTarget = true;
			if(this.options.multistates=="true"){
				this.audioTarget.hover(this.onOverAudio, this.onOffAudio);

				this.audioTarget.attr("multistates", "true");
			}
		}
		else this.isImgTarget = false;
		
		//initial state of the gadget
		this.audioState ="ready"; //ready, playing, paused
		this.audioTarget.attr("audiostate", "ready");
		this.lastPct = 0;
		this.audioPct= 0;
		
		//create an initial global audio player
		this.initAudioPlayer();
    
		//create audio button if needed
		var rand = this.randomID();
		this.audioid = rand; 
		this.audioTarget.attr("randomid", rand);
		this.audioTarget.addClass("audioTarget");
		this.audioTarget.css("cursor", "pointer");
		this.audioTarget.css("z-index", "10"); //at least 10 to stay on top
		this.audioTarget = this.audioTarget;			
				
		//register the event to the audio target
		var me=this;
		this.audioTarget.click(function(){me.onAudioClicked()}); //state machine controller
	},
	
	initAudioPlayer:function(){ //create a global audio player, hide it
		if(!this.isHTML5Audio()){		
      this.initFlashAudioPlayer();
		}
		else{ //html
			this.initHTML5AudioPlayer();
		}
		
		if(this.isImgTarget && this.options.showprogress=="true" && this.options.multistates=="true" && !this.isIE78()){
			//this.circleprogress = new CircleProgress(this.audioTarget.attr("id"));
			this.addProgressCircle();
		}
	},
	
	initFlashAudioPlayer: function(){
			if($("#inline_swf_audio_player").attr('class')==undefined){
				$('body').append('<div id="inline_swf_audio_player" class="jp-jplayer" audio="'+this.audioSrc+'"></div>');
				$('#inline_swf_audio_player').css({'position': 'absolute', 'z-index':'-10', 'left':'0','top':'0','width':'0','height':'0'})
			
				$('#inline_swf_audio_player').jPlayer({
					ready: function (){},
					solution:"flash,html",
					supplied: "mp3",
					preload: "auto"
				});					
			}
      
			var me=this; //assign me to this.
			
			$('#inline_swf_audio_player').bind($.jPlayer.event.timeupdate , function(e) { //get the current percent of the audio

        me.audioPct = parseInt(e.jPlayer.status.currentPercentAbsolute);

				if(me.audioTarget.attr("audiostate")=="ready"){
					me.lastPct=0;
					me.audioPct=0;
					return; 
				}
				
				if(me.lastPct==0 && me.audioPct==0){
					me.lastPct=0;
				}
				else if(me.lastPct>=0 && me.audioPct>0){
					me.lastPct=me.audioPct-1;
				}
				else if (me.lastPct>0 && me.audioPct==0){
					me.audioPct=100;
				}

				if(me.audioPct==100){//if it is 100% no more progress
					return; 
				}
				if(me.isImgTarget && me.options.showprogress=="true" && me.options.multistates=="true" && me.audioTarget.attr("audiostate")=="playing" && me.lastPct<100){
					me.progress(me.audioPct);
				}
      });
			
			$('#inline_swf_audio_player').bind($.jPlayer.event.ended, function(){me.onAudioComplete(me.audioid);});	
	},
	
	initHTML5AudioPlayer: function(){
		if($("#inline_html_audio_player").attr("src")==undefined){
				$('body').append('<audio id="inline_html_audio_player" src="" ></audio>');
				$('#inline_html_audio_player').css({'position': 'absolute', 'z-index':'-10', 'left':'0','top':'0','width':'0','height':'0'})
		}
		var audioPlayer = document.getElementById("inline_html_audio_player");
			
		var me=this;
			
		audioPlayer.addEventListener("timeupdate", function(){
				me.audioPct = (audioPlayer.currentTime / audioPlayer.duration) * 100;
				me.lastPct=me.audioPct-1;
				if(me.isImgTarget && me.options.showprogress=="true" && me.options.multistates=="true" && me.audioTarget.attr("audiostate")=="playing" && me.lastPct<100){
					me.progress(me.audioPct);
				}								
		});
			
		audioPlayer.addEventListener("ended", function(){me.onAudioComplete(me.audioid);});
	},
	
	addProgressCircle: function(){//give the wrapper div a width and height of 100px to make sure it is big enough, then align it to the center of the wrapped image
		var audioImgId = this.audioTarget.attr("id"); 
    $('div.page').append('<img style="position:absolute; top:15px; left:-10px;" src="css/gadget/audio/audio-bg.png">');
		
		//the audio target's image position must be absolute, it must have top, left, width and height px values in its CSS
		var leftpx = this.audioTarget.css("left");
		var left = parseInt(leftpx.substring(0, leftpx.length-2));
		var toppx = this.audioTarget.css("top");
		var top = parseInt(toppx.substring(0, toppx.length-2));
    var widthpx = this.audioTarget.css("width");		
		var targetWidth = parseInt(widthpx.substring(0, widthpx.length-2));
		var heightPx = this.audioTarget.css("height");
		var targetHeight = parseInt(heightPx.substring(0, heightPx.length-2));

		var divLeft = parseInt(left+targetWidth*0.5-25); //25 is half of 50px. 50px is the size of the circle
		var divTop = parseInt(top+targetHeight*0.5-25);
		
    //console.log("top:"+top+" left:"+left+" my img width:"+targetWidth+" height:"+targetHeight+" my top:"+divTop+" my left"+divLeft);
		var ranId = this.randomID();
		this.circleProgressId = ranId; 
    //console.log("<div id='"+ranId+"' parentid='"+audioImgId+"' style='position:absolute; z-index:-1; margin:0; border:0; padding:0; width:50px; height:50px; top:"+divTop+"px; left:"+divLeft+"px;'></div>")
		//$("body").append("<div id='"+ranId+"' parentid='"+audioImgId+"' style='position:absolute; z-index:1; margin:0; border:0; padding:0; width:50px; height:50px; top:"+divTop+"px; left:"+divLeft+"px;'></div>")
		this.audioTarget.after("<div id='"+ranId+"' parentid='"+audioImgId+"' style='position:absolute; z-index:1; margin:0; border:0; padding:0; width:50px; height:50px; top:"+divTop+"px; left:"+divLeft+"px;'></div>")
		$("#"+ranId).append('<div class="empty" style="position:absolute; background:#333; z-index:1; width:100%; height:100%; top:0; left:0; background:url(css/gadget/audio/buffer1.png) 50% 50% no-repeat;"><div class="slice"><div class="pie"></div></div></div>');		
	},

	progress: function(percent){//draw the circle
		//console.log(this.audioTarget.attr("id")+" "+percent+ " state "+this.audioTarget.attr("audiostate"));

		if(percent==0){
      return;          
    }
		else if(percent<2){
      $("#"+this.circleProgressId).find(".slice").attr("class", "slice");          
    }
    else if(percent>50){
      $("#"+this.circleProgressId).find('.slice').addClass("gt50");
    }		
		else if(percent==100){
			return;
		}

		var deg = 360/100*percent;
		
		$("#"+this.circleProgressId).find('.pie').css({
				'-moz-transform':'rotate('+deg+'deg)',
				'-webkit-transform':'rotate('+deg+'deg)',
				'-o-transform':'rotate('+deg+'deg)',
				'transform':'rotate('+deg+'deg)'
		});
	},
	
	resetZero: function(){
		//console.log("After 100%, reset to 0%");
		//for(var i=0; i<10000; i++){	}/// loop to delay
		$("#"+this.circleProgressId).find('.slice').removeClass("gt50").find('.pie').css({
			'-moz-transform':'rotate('+0+'deg)',
			'-webkit-transform':'rotate('+0+'deg)',
			'-o-transform':'rotate('+0+'deg)',
			'transform':'rotate('+0+'deg)'
		}).removeAttr("style");
	},
	
	onAudioClicked: function(){ //this is the state machine here that update the whole audio from state 1 to state 2 with actions applied onto the audio player.
		if(this.audioTarget.attr("audiostate")=="ready"){
			this.audioTarget.attr("audiostate", "playing")
			this.start(); //start will affect other audios. 
		}
		else if(this.audioTarget.attr("audiostate")=="playing"){
			this.audioTarget.attr("audiostate", "paused")			
			this.pause();
		}
		else if(this.audioTarget.attr("audiostate")=="paused"){
			this.audioTarget.attr("audiostate", "playing")			
			this.resume();
		}
	},
	
	/* This API will be called by both the Flash and HTML5 player */
	onAudioComplete: function(completedAudioId){ /* The audio is played to the end */
    //change the button state
		if(this.isImgTarget && this.options.multistates=="true" && this.audioid==completedAudioId){
			$('img[randomid="'+this.audioid+'"]').attr("src", "css/gadget/audio/play.png");
		}
		
		//reset the gadget state
		if(this.isImgTarget && this.options.showprogress=="true" && this.options.multistates=="true"){
      if(this.audioTarget.attr("audiostate")=="playing"){
			  this.progress(100);
			}
			else
			  this.progress(0);
		}						
		this.audioTarget.attr("audiostate", "ready");
		var me=this;
		setTimeout(function(){me.resetZero();}, 500);
	},
	
	onOverAudio: function(){  //in the event handler API, "this" is the current event target dom node
    var s = $(this).attr("src"); 
    var reg = new RegExp("\/([a-zA-Z0-9_]+)\.([a-zA-Z]{3})$", "g");
    var btnImg = reg.exec(s);
    s=s.replace(btnImg[0], "/");
    $(this).attr('src', s+btnImg[1]+'_over.'+btnImg[2]);
	},
	
	onOffAudio: function(){ //change x_over.png to x.png
    var s = $(this).attr("src");
    var reg = new RegExp("\/([a-zA-Z0-9]+)_over\.([a-zA-Z]{3})$", "g");
    var btnImg = reg.exec(s);
    if(btnImg)
		  s=s.replace(btnImg[0], "/");
    $(this).attr('src', s+btnImg[1]+'.'+btnImg[2]);
	},
	
	start: function(){ //from ready to playing state
		//this.audioPct=0;
		this.stopOtherAudios();
		
    if(this.isImgTarget && this.options.multistates=="true"){
      this.audioTarget.attr("src", "css/gadget/audio/pause.png");
		}
		
		if(!this.isHTML5Audio()){
			$('#inline_swf_audio_player').jPlayer("setMedia", {mp3:this.audioSrc}).jPlayer("play");
		}
		else{ //ipad etc HTML5 native audio player
  	  var hiddenaudio = document.getElementById("inline_html_audio_player");
			hiddenaudio.pause();
			hiddenaudio.src=this.audioSrc;
		  hiddenaudio.play();
		}
	},

	pause:function(){
		if(!this.isHTML5Audio()){
			$('#inline_swf_audio_player').jPlayer("pause"); 
		}
		else{
  	  var hiddenaudio = document.getElementById("inline_html_audio_player");
		  hiddenaudio.pause();
		}
    
		//then the button state
		if(this.isImgTarget && this.options.multistates=="true"){
      this.audioTarget.attr("src", "css/gadget/audio/play.png");
		}
	},
	
	resume: function(){ //click to go from paused state to playing state
		if(!this.isHTML5Audio()){
			$('#inline_swf_audio_player').jPlayer("play"); 
		}
		else{ //ipad etc HTML5 native audio player
  	  var hiddenaudio = document.getElementById("inline_html_audio_player");
		  hiddenaudio.play();
		}
		
		if(this.isImgTarget && this.options.multistates=="true"){
      this.audioTarget.attr("src", "css/gadget/audio/pause.png");
		}
	},
	
	stopOtherAudios: function(){
		var me=this;
		//reset the circle to its initial ready states
		$("body").find(".slice").each(function(){
			$(this).parent().empty().html("<div class='slice'><div class='pie'></div></div>");
		});
		
		$("body").find(".audioTarget").each(function(){ /* Reset all audio buttons in the same class*/
      var audioBtnId = $(this).attr("randomid");
			if(me.audioTarget.attr("randomid")!=audioBtnId){ //stop the other audio
  		  //console.log("My id "+me.audioTarget.attr("randomid")+" your id "+audioBtnId);
				$('img[randomid="'+audioBtnId+'"]').attr("audiostate", "ready");
				if($('img[randomid="'+audioBtnId+'"]').attr("multistates")=="true") //if the audio image has multi states
				  $('img[randomid="'+audioBtnId+'"]').attr("src", "css/gadget/audio/play.png");
					//$("#"+this.circleProgressId).find(".slice").removeClass("gt50");
				
			}
		});
    
		if(!this.isHTML5Audio()){
			if($('#inline_swf_audio_player').attr("audio")!=me.audioSrc){			
				$('#inline_swf_audio_player').jPlayer("pauseOthers"); 
				$('#inline_swf_audio_player').jPlayer("clearMedia"); 			
			}
		}

		$(".pie").css({
			'-moz-transform':'rotate('+0+'deg)',
			'-webkit-transform':'rotate('+0+'deg)',
			'-o-transform':'rotate('+0+'deg)',
			'transform':'rotate('+0+'deg)'
		});		
	},
	
	isHTML5Audio: function(){
		if((/iphone|ipod|ipad|Safari/i).test(navigator.userAgent))
		  return true;
		else
		  return false;
	},

	isIE78: function(){
		if((/MSIE 8/i).test(navigator.userAgent))
		  return true;
		else if((/MSIE 7/i).test(navigator.userAgent))
		  return true;
		return false;
	},
	
	randomID: function(){ /* a lightweight service API to generate a random string for ID */
		var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
		var random = '';
		for (var i=0; i<10; i++) {
			var rnum = Math.floor(Math.random() * chars.length);
			random += chars.substring(rnum,rnum+1);
		}
		return random;
  }		
});


