var mouseToTouch = new Class({
 
	Implements: [Options, Events],
 
	options: {
  
	},
 
	jQuery: 'mouseToTouch',
 
 	initialize: function(selector, options){
  		this.setOptions(options); // inherited from Options like jQuery.extend();
  		this.jObject = jQuery(selector); // cache the jQuery object, could be a list
  		this.mobile();
 	},
 
  	mobile: function(){ //test options
    	var me = this;
     	var obj = this.jObject
     
     	obj.each(function(){
     		$(this)[0].addEventListener("touchstart", function(event){me.touchHandler(event);}, true);
    		$(this)[0].addEventListener("touchmove", function(event){me.touchHandler(event);}, true);
    		$(this)[0].addEventListener("touchmove", function(event){event.preventDefault();}, true);
     		$(this)[0].addEventListener("touchend", function(event){me.touchHandler(event);}, true);
     		$(this)[0].addEventListener("touchcancel", function(event){me.touchHandler(event);}, true);
  	  	});
 	},
 
 	touchHandler: function(event){
    	var touches = event.changedTouches,
        first = touches[0],
        type = "";
 
    	switch(event.type){
       		case "touchstart": type ="mousedown"; break;
        	case "touchmove":  type="mousemove"; break;       
        	case "touchend":   type="mouseup"; break;
        	default: return;
    	}
    	var fakedMouseEvent = document.createEvent("MouseEvent");
    	fakedMouseEvent.initMouseEvent(type, true, true, window, 1,
                              first.screenX, first.screenY,
                              first.clientX, first.clientY, false,
                              false, false, false, 0/*left*/, null);
 
    	first.target.dispatchEvent(fakedMouseEvent);
 	}
});