/**
  This is a global object, to contain the SCO level SCORM data. It will keep a data structure for all gadgets on a given page.
  This class' API can be called by the gadget. It can also be called by the SCO.js and page.js for events like window is closed
  or page is unloaded. 
*/
var ScormProxy = new Class({
	Implements: [Options, Events], 
	
	Extends: gadget,
	
	options: {
			scoid: 'A000000' //a SCO ID to identify the SCO
	},
	
	jQuery: 'scormproxy',
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
    this.selector = selector;
		this.scorm = pipwerks.SCORM;
		this.scoid=options.scoid; //pass over the scoid
		this.scodata={}; //the sco suspend data
    this.scodata["scoid"]=this.scoid;
		
		this.isSCORM = this.scorm.init();
		
		return;
	},
	
	/*
	 A gadget will call this API to set the gadget data into a global data structure.
	*/
	setGadgetData: function(pageId, gadgetId, gadgetData){
		var gadgetJson = {};
		gadgetJson[gadgetId] = gadgetData;
		this.scodata[pageId] = gadgetJson;
		////console.log("scormproxy.js: "+JSON.stringify(this.scodata));
	},

	/*
	 A gadget will call this API to get the gadget data from suspend data to restore to its earlier state
	*/
	getGadgetData: function(pageId, gadgetId){
		var gadgetJson = this.scodata[pageId];
    if(gadgetJson){
		  ////console.log("scormproxy.js: Gadget suspend data " + gadgetJson[gadgetId]);
		  return gadgetJson[gadgetId];
		}
		else
		  return null;
	},
	
	/*
	 When a SCO is closed, the SCO player will call this API to make sure it send the data back to LMS
	*/
	closeSCO: function(){
		this.storeSCOSuspendData();
		if(this.isSCORM){
			this.scorm.quit();
		}
	},
	
	/*
	 A SCO or page will call this API to set the SCO level data,
	 The triggering events could be when a SCO is started or closed, or when a page is navigated. 
	*/
	setSCOLocation: function(currentPageIndex){
		if(this.isSCORM){
			this.scorm.set("cmi.location", currentPageIndex);
		}
		else{
			if(typeof(Storage)!= "undefined"){
				sessionStorage.setItem("cmi.location", currentPageIndex);
			}
		}
	},
	
	storeSCOSuspendData: function(){
		var scoScormData = JSON.stringify(this.scodata);
    //alert("Has scorm obj? "+typeof(Storage));
		if(this.isSCORM){
		  this.scorm.set("cmi.suspend_data", scoScormData);
		  this.scorm.save(); //scorm commit
		}
		else{
			if(typeof(Storage)!= "undefined"){
				sessionStorage.setItem(this.scoid+".cmi.suspend_data", scoScormData);
			}
		}
	},
	
	/*
	 Get the stored SCO suspend data from the LMS thru SCORM API, and restore the data into the current object. 
	*/
	restoreSCOSuspendData: function(){
		var suspendData;
		if(this.isSCORM){
		  suspendData = this.scorm.get("cmi.suspend_data");
		  if(suspendData) this.scodata = JSON.parse(suspendData); //only if there is suspend data from the SCO's previous sessions
		}
		else{ //we will use HTML5 session storage to simulate
			if(typeof(Storage)!= "undefined"){
				if(sessionStorage.getItem(this.scoid+".cmi.suspend_data")){
					suspendData = sessionStorage.getItem(this.scoid+".cmi.suspend_data");
					////console.log("scormproxy.js: find suspend data: "+suspendData);
					this.scodata = JSON.parse(suspendData);
				}
			}
			else{ //this is for IE, without session storage
				this.scodata={};
			}
		}
	}
});


