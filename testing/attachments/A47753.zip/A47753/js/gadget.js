var gadget = new Class({
	
	Implements: [Options, Events], 

		options: {
			inline: 'false',
			draggable: 'true',
			foldable: 'true',
			resizable: 'true',
			swipeDelta: 10 //default swipe distance is 10 pixels
		},

	jQuery: 'gadget',

	initialize: function(selector, options){
		this.setOptions(options); // inherited from Options like jQuery.extend();
		this.$Obj = $(selector); // cache the jQuery object, could be a list
		this.eventTrace={isTouched:false, isDragged:false, isSwiped:false, isPinched:false};

		this.attach();
		this.mobile();
	},
	
	getJqObj: function(){
	  return this.$Obj;	
	},
	
  mobile: function(){ //test options
		var myobj=this;
		this.$Obj.each(function(){
			var current$ = $(this)[0];
			current$.addEventListener("touchstart", function(event){myobj.touchHandler(event);}, true);
    	current$.addEventListener("touchmove", function(event){myobj.touchHandler(event);}, true);
    	current$.addEventListener("touchend", function(event){myobj.touchHandler(event);}, true);
    	current$.addEventListener("touchcancel", function(event){myobj.touchHandler(event);}, true);			

			current$.addEventListener("gesturestart", function(event){myobj.pinchHandler(event);}, true);
    	current$.addEventListener("gesturechange", function(event){myobj.pinchHandler(event);}, true);
    	current$.addEventListener("gestureend", function(event){myobj.pinchHandler(event);}, true);
			
			current$.addEventListener("mousedown", function(event){myobj.mouseHandler(event);}, true);
    	current$.addEventListener("mousemove", function(event){myobj.mouseHandler(event);}, true);
    	current$.addEventListener("mouseup", function(event){myobj.mouseHandler(event);}, true);
			
		});
		return this;
	},
	
	initWipeEvent: function(firstTouch){
		this.eventTrace.isTouched=true;
		this.eventTrace.isDragged=false; //reset
		this.eventTrace.isSwipped=false;
		this.eventTrace.isPinched=false;
		
		this.swipe=new Object(); //storage of swipe event data
		this.swipe.mode = "drag"; // "drag", "swipe", "tap"
		this.swipe.input="finger"; //finger, mouse
		this.swipe.firstTouchX=firstTouch.pageX;
		this.swipe.firstTouchY=firstTouch.pageY;
		this.swipe.lastTouchX=firstTouch.pageX;
		this.swipe.lastTouchY=firstTouch.pageY;
		this.swipe.preTouchX=firstTouch.pageX;
		this.swipe.preTouchY=firstTouch.pageY;
		this.swipe.currTouchX=firstTouch.pageX;
		this.swipe.currTouchY=firstTouch.pageY;
		this.swipe.target=firstTouch.target;
		this.swipe.currentTarget=this.swipe.target;
		this.swipe.direction = ""; //up, down, left, right, none
	},
	
	touchHandler: function(event){
		event.preventDefault();

		if(event.targetTouches.length>1){
			//console.log("Multi touch");
			return;
		}
		
		var touch = event.changedTouches[0];
		if(event.type=="touchstart") {
			this.initWipeEvent(touch);
			return;
		}
		
		if(event.type=="touchmove"){
		  this.swipe.currTouchX=touch.pageX;
		  this.swipe.currTouchY=touch.pageY;
			var deltaX = Math.abs(this.swipe.currTouchX-this.swipe.preTouchX);
			var deltaY = Math.abs(this.swipe.currTouchY-this.swipe.preTouchY);
			if(deltaX>=deltaY) this.swipe.direction = (this.swipe.currTouchX-this.swipe.preTouchX)>0?"right":"left";
			else this.swipe.direction = (this.swipe.currTouchY-this.swipe.preTouchY)>0?"down":"up";
			
			if(deltaX>10 || deltaY>10) this.swipe.mode="swipe";
			else this.swipe.mode = "drag";
			////console.log("mode is "+this.swipe.mode);
			
			if(this.swipe.mode=="swipe" && !this.eventTrace.isPinched){ //only fire swipe once
				this.fireEvent("swipe", this.swipe);
				this.eventTrace.isSwiped=true;
			}
			else if(this.swipe.mode=="drag" && !this.eventTrace.isPinched){
				this.fireEvent("drag", this.swipe);
				this.eventTrace.isDragged=true;
			}
			
			//console.log(this.swipe.currTouchX+":"+this.swipe.currTouchY+", last:"+this.swipe.preTouchX+":"+this.swipe.preTouchY);

		  this.swipe.preTouchX=this.swipe.currTouchX;
			this.swipe.preTouchY=this.swipe.currTouchY;
			return;
		}
		
		if(event.type=="touchend"){
		  this.swipe.lastTouchX=touch.pageX;
		  this.swipe.lastTouchY=touch.pageY;
			this.eventTrace.isSwiped=false;

			if((this.swipe.lastTouchX-this.swipe.firstTouchX)==0 && (this.swipe.lastTouchY-this.swipe.firstTouchY)==0){
				this.swipe.mode = "tap";
				this.swipe.direction = "none";
			  this.fireEvent("tap", this.swipe);
			}
			return;
		}
	},
	
	pinchHandler: function(event){
		event.preventDefault();
	
		if(event.type=="gesturestart"){
			this.pinch=new Object();
			this.pinch.target = event.target;
			this.pinch.rotation=0;
			this.pinch.scale=0;
			this.pinch.finalrotation=0;
			this.pinch.finalscale=0;
			this.eventTrace.isPinched=false;			
		}
		
		if(event.type=="gesturechange"){
			this.pinch.rotation = event.rotation;
			this.pinch.scale = event.scale;
			this.fireEvent("pinch", this.pinch);
			this.eventTrace.isPinched=true;
		}
		
		if(event.type=="gestureend"){
			this.pinch.finalrotation = event.rotation;
			this.pinch.finalscale=event.scale;
			this.fireEvent("finalpinch", this.pinch);
		}
				
	},
	
	mouseHandler: function(event){
		event.preventDefault();
		if(event.type=="mousedown"){
			this.initWipeEvent(event);
			this.swipe.input="mouse"; //finger, mouse
			return;
		}
		
		if(event.type=="mousemove" && this.swipe && this.swipe.input=="mouse"){
		  this.swipe.currTouchX=event.pageX;
		  this.swipe.currTouchY=event.pageY;
			var deltaX = Math.abs(this.swipe.currTouchX-this.swipe.preTouchX);
			var deltaY = Math.abs(this.swipe.currTouchY-this.swipe.preTouchY);
			if(deltaX>=deltaY) this.swipe.direction = (this.swipe.currTouchX-this.swipe.preTouchX)>0?"right":"left";
			else this.swipe.direction = (this.swipe.currTouchY-this.swipe.preTouchY)>0?"down":"up";
			this.fireEvent("drag", this.swipe);			
		}
		
		if(event.type=="mouseup"){
		  this.swipe.lastTouchX=event.pageX;
		  this.swipe.lastTouchY=event.pageY;
			this.swipe.input="finger"; //finger, mouse

			if((this.swipe.lastTouchX-this.swipe.firstTouchX)==0 && (this.swipe.lastTouchY-this.swipe.firstTouchY)==0){
				this.swipe.mode = "tap";
				this.swipe.direction = "none";
			  this.fireEvent("tap", this.swipe);
			}
			return;
		}		
	},
	
	attach: function(){
		this.addEvent("drag", function(event){this.onDrag(event);});
		this.addEvent("swipe", function(event){this.onSwipe(event);});
		this.addEvent("tap", function(event){this.onTap(event);});
		this.addEvent("pinch", function(event){this.onPinch(event);});
		this.addEvent("finalpinch", function(event){this.onFinalPinch(event);});
	},
	
	detach: function(){
	  //this.removeEvent("customEvent", function(){alert("Got new event");})
		return this;
	},
	
	onDrag: function(event){},

	onSwipe: function(event){},

	onTap: function(event){},
	
	onPinch: function(event){},
	
	onFinalPinch: function(event){}

	
});

