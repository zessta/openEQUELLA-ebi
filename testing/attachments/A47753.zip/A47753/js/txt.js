var txt = new Class({
	Implements: [Options, Events], 
	
	options: {
		value: 'default text',
		audio: "auth/audio/AVA101775.mp3"
	},
	
	jQuery: 'txt', //must be after options
	
	initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q.
		this.textObj = $(selector);
		this.options = options;
		this.audioSrc = options.audio;
		this.audioState ="paused"; //paused and playing
		this.audioPlayed = false;
		
		//put the text value into the HTML of the text
		this.textObj.html(options.value);
		
		//If the text has audio, an image button will be added in front of the button, then the audio player will be added to the image button
		if(this.audioSrc && this.audioSrc.length>0){
			var audioImgNodeId = this.randomID();
		  this.textObj.before("<img class='txtaudio' id='"+audioImgNodeId+"' src='css/gadget/txt/play.png' style='position:absolute; cursor:pointer; z-index:10;'>");
			this.audioBtn = this.textObj.prev('.txtaudio');
			this.audioBtn.css({"top":this.textObj.css("top"), "left":this.textObj.css("left")});
			this.textObj.css("padding-left", "40px");
      
			var me=this;
			setTimeout(function(){new Audio("#"+audioImgNodeId,{"src": me.audioSrc});}, 500);
		}
		
	},
	
	randomID: function(){
		var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
		var random = '';
		for (var i=0; i<8; i++) {
			var rnum = Math.floor(Math.random() * chars.length);
			random += chars.substring(rnum,rnum+1);
		}
		return random;
  }		
	
});


