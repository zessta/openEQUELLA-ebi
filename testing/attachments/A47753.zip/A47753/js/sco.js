/*
 1. Load and parse sco.json file and load it into memory object
 2. Load in the first page in the json
 3. Track where you are in the page flow
 4. Update browser history
 5. Manage player level events such as navigation clicks, and load the right page
 6. load in SCORM
*/
var scormproxy=null; //the only global variable which is a object for SCORM, it is accessible to each gadget 

$(document).ready(function(){
	preloader();
	initSCO();
	
	//register event when the SCO is closed
	$(window).unload(function() {
    if(scormproxy) scormproxy.storeSCOSuspendData();
  });
});

function initSCO(){
  $.getJSON("auth/sco.json", function(sco){  //load in the page files as a json array

		//start SCORM data tracking    
		scormproxy = new ScormProxy("body", {"scoid": sco.title}); //create a scorm proxy object
		scormproxy.restoreSCOSuspendData(); //read the stored suspend data from the LMS and store it into the proxy's object
		//alert(" Restore SCORM suspend data");

		var totalPages = sco.pages.length;
		//alert("Total pages "+totalPages+" page is created")
		var page = new Page('.main', {pageArray: sco.pages}); //one page object for the whole sco

    updateIndex(1, totalPages);
    

		//$('#prev').buttonizer();
		$('#next').hover(function(){$(this).attr("src", "css/theme/next_over.png");}, function(){$(this).attr("src", "css/theme/next.png")});
		
    $('#prev').click(function(){var index = page.prev(); updateIndex(index, totalPages);});
    $('#next').click(function(){var index = page.next(); updateIndex(index, totalPages);});
  });	
}

function updateIndex(pageIndex, totalPages){
  $('#pageIndex').html(pageIndex+" of "+totalPages);
	if(pageIndex==1) {
		$("img#prev").attr("src", "css/theme/prev_dead.png");
		$("img#prev").unbind('mouseenter mouseup mousedown mouseleave');
	}
	else {
		$("img#prev").attr("src", "css/theme/prev.png");
		$('img#prev').hover(function(){$(this).attr("src", "css/theme/prev_over.png");}, function(){$(this).attr("src", "css/theme/prev.png")});
		$('img#prev').mousedown(function(){$(this).attr("src", "css/theme/prev_down.png");});
		$('img#prev').mouseup(function(){$(this).attr("src", "css/theme/prev.png");});
	}

	if(pageIndex==totalPages){
		$("img#next").attr("src", "css/theme/next_dead.png");
		$("img#next").unbind('mouseenter mouseup mousedown mouseleave');
	}
	else{
		$("img#next").attr("src", "css/theme/next.png");
		$('img#next').hover(function(){$(this).attr("src", "css/theme/next_over.png");}, function(){$(this).attr("src", "css/theme/next.png")});
		$('img#next').mousedown(function(){$(this).attr("src", "css/theme/next_down.png");});
		$('img#next').mouseup(function(){$(this).attr("src", "css/theme/next.png");});
	}
}

function preloader(){
	if((navigator.appVersion.indexOf("MSIE 7.")>=0) ) return; //IE7 has trouble.
	
 	$(".sco").append("<div id='preloader'><img id='preloader' src='css/theme/preloader.gif'/></div>");

	$('img#preloader').fadeOut('650',function(){
		$('div#preloader').fadeOut('650',function(){
			$("div#preloader").remove();
		});
	});		
	
}