var Page = new Class({
  Implements: [Options, Events],
  
  options:{
    currPageIndex: 0,  //the current page index
    pageArray: [],  //default is empty
    totalPages:1 //default is 1
  },
  
	jQuery: 'page',
  
  initialize: function(selector, options){ //initlalized is a reserved API for Moo4Q. 
    this.jObject = jQuery(selector);
    this.selector = selector;
    this.setOptions(options);
    this.options.totalPages = this.options.pageArray.length;
		this.gadgetsOnPage={};
		this.pageJsons=[];
		this.pageModels=[];
		this.pageSCORM={}; //the format will be {"pageID":{"gadgetID":{}, "gadgetID":{}}, "pageID":{}}
    this.loadPage();		
  },
  
  next: function(){
    if(this.options.currPageIndex<this.options.totalPages-1){
			this.options.currPageIndex++;
      this.loadPage();
    }
		return this.options.currPageIndex+1;
  },
  
  prev: function(){
    if(this.options.currPageIndex>0){
      this.options.currPageIndex--;
      this.loadPage();
    }
		return this.options.currPageIndex+1;		
  },
  
	/*
	 The current page will be unloaded, a new page will be loaded. Before the current page is unloaded, we will store its SCORM data. 
	*/
	loadPage: function(){
		scormproxy.storeSCOSuspendData(); //whenever a page is navigated, commit the SCO data to LMS
    var me = this; //this variable is to differentiate from this to refer to jQuery's internal loop		
		
		if(me.pageJsons[me.options.currPageIndex]!=undefined){
		  me.populatePage();
		}
		else
    $.ajax({url:"auth/"+me.options.pageArray[me.options.currPageIndex]+"?token="+me.randomID(),
					  dataType: "json",
					  success: function(pageJson){ //load in pageX.json
							me.pageJsons[me.options.currPageIndex] = pageJson;
							
							if(me.pageModels[me.options.currPageIndex]==undefined)
								$.get("model/"+pageJson.type+".html"+"?token="+me.randomID(), //this could be served from cache once the html page is loaded once
									function(pageHtml){ //call back for each page
										me.pageModels[me.options.currPageIndex]=pageHtml;
										me.populatePage();
								});
							else
								me.populatePage();
    }});
  },
	
	populatePage: function(){
		var gadget_facts={};
		var me=this;
		var pageJson = me.pageJsons[me.options.currPageIndex];
		var pageHtml = me.pageModels[me.options.currPageIndex];
    var pageModel = $("<div/>").replaceWith(pageHtml); //get the DOM of the HTML skeleton main ito a floating div
		pageModel.attr("id", "page"+me.options.currPageIndex); //create a page id based on its index (based on 0)

    pageModel.find("[data-gadget]").each(function(){ //find all the gadget placeholders out of current page html model
		  var gadgetObj = {};                  
		  var gadget_id=$(this).attr("data-id"); //every gadget has a class attr to uniquely identify the gadget in the page
		  gadgetObj.type=$(this).attr("data-gadget");
		  gadgetObj.json=pageJson[""+gadget_id];
																
  	  gadget_facts[""+gadget_id]=gadgetObj;
		  me.gadgetsOnPage[""+me.options.currPageIndex] = gadget_facts; //the data structure keeps all the gadgets on each page by page ID
    });
		
		$('.main').empty().append(pageModel); //populate the main with the current page skeleton
		me.populateGadgets(me.gadgetsOnPage[""+me.options.currPageIndex]);
	  	
	},
	
	populateGadgets: function(pageGadgetsJson){
		var me = this;
		$("div#page"+me.options.currPageIndex).find("[data-gadget]").each(function(){
			var gadget_class = $(this).attr("class");
			var gadget_id = $(this).attr("data-id");
			me.populateGadget("#page"+me.options.currPageIndex+" ."+gadget_class, pageGadgetsJson[""+gadget_id].type, pageGadgetsJson[""+gadget_id].json);
		});
	},
	
	populateGadget: function(selector, gadgetType, gadgetJson){
		////console.log("constructing gadget "+gadgetType+" at selector "+selector+" with json" +gadgetJson);
		if(gadgetType=="txt") new txt(selector, gadgetJson); 
		else if(gadgetType=="img") new img(selector, gadgetJson); 
		else if(gadgetType=="fib") new fib(selector, gadgetJson);
		else if(gadgetType=="video") new video(selector, gadgetJson);
		else if(gadgetType=="sa") new sa(selector, gadgetJson);
	},

	randomID: function(){
		var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
		var random = '';
		for (var i=0; i<8; i++) {
			var rnum = Math.floor(Math.random() * chars.length);
			random += chars.substring(rnum,rnum+1);
		}
		return random;
  }	
	
});

